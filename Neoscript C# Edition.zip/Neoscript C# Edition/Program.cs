﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;

// Kho lưu trữ biến
Dictionary<string, string> variables = new Dictionary<string, string>();

// Lấy file kịch bản (mặc định là ide.ns)
string filePath = args.Length > 0 ? args[0] : "ide.ns";

if (!File.Exists(filePath))
{
    Console.WriteLine($"System Error: {filePath} not found!");
    return;
}

// Đọc tất cả các dòng
string[] lines = File.ReadAllLines(filePath);

foreach (string rawLine in lines)
{
    string line = rawLine.Trim();
    // Bỏ qua dòng trống và note
    if (string.IsNullOrEmpty(line) || line.StartsWith("note")) continue;

    int spaceIndex = line.IndexOf(' ');
    string cmd = spaceIndex == -1 ? line : line.Substring(0, spaceIndex);
    string arg = spaceIndex == -1 ? "" : line.Substring(spaceIndex + 1);

    switch (cmd)
    {
        case "set":
            int sPos = arg.IndexOf(' ');
            if (sPos != -1)
            {
                string name = arg.Substring(0, sPos);
                string val = arg.Substring(sPos + 1).Trim('"');
                variables[name] = val;
            }
            break;

        case "write":
            string writeVal = arg.Trim('"');
            Console.WriteLine(variables.ContainsKey(writeVal) ? variables[writeVal] : writeVal);
            break;

        case "add":
            ExecuteMath(arg, true);
            break;

        case "sub":
            ExecuteMath(arg, false);
            break;

        case "input":
            // Nhập số (v1.0)
            variables[arg.Trim()] = Console.ReadLine();
            break;

        case "input_str":
            // Nhập chuỗi (v1.0)
            variables[arg.Trim()] = Console.ReadLine();
            break;

        case "wait":
            if (double.TryParse(arg, out double sec))
                Thread.Sleep((int)(sec * 1000));
            break;

        case "clear":
            Console.Clear();
            break;

        case "color":
            if (arg == "\"red\"") Console.ForegroundColor = ConsoleColor.Red;
            else if (arg == "\"green\"") Console.ForegroundColor = ConsoleColor.Green;
            else if (arg == "\"cyan\"") Console.ForegroundColor = ConsoleColor.Cyan;
            else Console.ResetColor();
            break;
    }
}

// Hàm xử lý toán học thông minh (biến + biến hoặc biến + số)
void ExecuteMath(string arg, bool isAddition)
{
    string[] parts = arg.Split(' ', StringSplitOptions.RemoveEmptyEntries);
    if (parts.Length < 2) return;

    string varName = parts[0];
    string valueToProcess = parts[1];

    if (variables.ContainsKey(varName))
    {
        double current = double.Parse(variables[varName]);
        // Kiểm tra xem cộng với 1 biến khác hay cộng với số trực tiếp
        double amount = variables.ContainsKey(valueToProcess)
                        ? double.Parse(variables[valueToProcess])
                        : double.Parse(valueToProcess);

        variables[varName] = (isAddition ? current + amount : current - amount).ToString();
    }
}