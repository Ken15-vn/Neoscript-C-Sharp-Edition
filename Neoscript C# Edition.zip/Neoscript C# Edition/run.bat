@echo off
title NeoScript C# Edition - SR v1.0
"Neoscript C# Edition.exe" ide.ns
pause